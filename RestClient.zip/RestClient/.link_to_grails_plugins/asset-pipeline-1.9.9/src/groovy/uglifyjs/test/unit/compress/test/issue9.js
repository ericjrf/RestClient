var a = {
    a: 1,
    b: 2, // <-- trailing comma
};
