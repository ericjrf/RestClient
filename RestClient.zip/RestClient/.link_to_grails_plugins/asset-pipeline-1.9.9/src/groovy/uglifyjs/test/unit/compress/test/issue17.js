var a = function(b) {
    b();
    a()
}
