(function(){function a(){}return new a(1,2,3,4)})()
