ant.mkdir dir: "$basedir/grails-app/migrations"
